
local Clockwork = Clockwork;

Clockwork.hint:Add("BackpackSlots", "You have several backpack slots, use them wisely!");
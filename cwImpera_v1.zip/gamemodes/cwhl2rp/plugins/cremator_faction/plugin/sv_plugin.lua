local PLUGIN = PLUGIN;
local Clockwork = Clockwork;

-- Adds the "HL2 Beta SNPCs" workshop file to the server's FastDL.
resource.AddWorkshop("108511284");
resource.AddWorkshop("254077907");
ENT.Type = "anim";
ENT.Base = "base_gmodentity";
ENT.Author = "Arbiter";
ENT.PrintName = "CameraViewer";
ENT.Spawnable = false;
ENT.AdminSpawnable = false;
ENT.PhysgunDisabled = true;
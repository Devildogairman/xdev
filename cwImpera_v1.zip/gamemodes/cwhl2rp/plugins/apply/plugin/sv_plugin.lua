--[[
	� 2017 TeslaCloud Studios.
	Feel free to use, edit or share the plugin, but
	do not re-distribute without the permission of it's author.
--]]

Clockwork.config:Add("apply_recognise_enable", true);
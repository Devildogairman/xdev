Taco Config:

This particular plugin is -required- most of the plugins to function.
It was required to start with multiple A's, as to run before any of my other plugins.
This should not effect other plugins, nor should the existance of this plugin effect other plugins as a whole.
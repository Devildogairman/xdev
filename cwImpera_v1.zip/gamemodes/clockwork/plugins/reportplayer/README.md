Report Player
=================

Purpose
----

Report a player to the Cloud Sixteen official reports tracker.
--[[
This work is licensed under a Creative Commons
Attribution-ShareAlike 4.0 International License.

Created by 8bitMafia.
--]]

local PLUGIN = PLUGIN;

PLUGIN:SetGlobalAlias("cwPlaySound");

Clockwork.kernel:IncludePrefixed("sv_plugin.lua");
Clockwork.kernel:IncludePrefixed("cl_plugin.lua");